﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace ProyectoIPO_Lab2324
{
    public partial class StaffWindow : Window
    {
        public ObservableCollection<Staff> StaffMembers { get; set; }

        public StaffWindow()
        {
            InitializeComponent();
            LoadSampleData();
            DataContext = this;
        }

        private void LoadSampleData()
        {
            StaffMembers = new ObservableCollection<Staff>
            {
                new Staff { FullName = "Maria Lopez", Age = 45, Phone = "555-1234", StaffType = "Sanitario", Specialty = "Enfermera", ExperienceYears = 10 },
                new Staff { FullName = "Pedro Gonzalez", Age = 50, Phone = "555-5678", StaffType = "Limpieza", Department = "Mantenimiento" }

            };
            StaffList.ItemsSource = StaffMembers;
        }

        private void StaffList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StaffList.SelectedItem is Staff selectedStaff)
            {
                StaffName.Text = selectedStaff.FullName;
                StaffAge.Text = selectedStaff.Age.ToString();
                StaffPhone.Text = selectedStaff.Phone;
                StaffType.Text = selectedStaff.StaffType;
                StaffSpecialty.Text = selectedStaff.Specialty;
                StaffExperienceYears.Text = selectedStaff.ExperienceYears.ToString();
                StaffDepartment.Text = selectedStaff.Department;
            }
        }

        private void SaveStaffChanges_Click(object sender, RoutedEventArgs e)
        {
            if (StaffList.SelectedItem is Staff selectedStaff)
            {
                selectedStaff.FullName = StaffName.Text;
                selectedStaff.Age = int.Parse(StaffAge.Text);
                selectedStaff.Phone = StaffPhone.Text;
                selectedStaff.StaffType = StaffType.Text;
                selectedStaff.Specialty = StaffSpecialty.Text;
                selectedStaff.ExperienceYears = int.Parse(StaffExperienceYears.Text);
                selectedStaff.Department = StaffDepartment.Text;
                MessageBox.Show("Los cambios han sido guardados", "Guardar", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ViewAttendedPatients_Click(object sender, RoutedEventArgs e)
        {
            // Implementar lógica para mostrar pacientes atendidos por el personal seleccionado
            MessageBox.Show("Mostrar pacientes atendidos (no implementado)", "Pacientes Atendidos", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    public class Staff
    {
        public string FullName { get; set; }
        public int Age { get; set; }
        public string Phone { get; set; }
        public string StaffType { get; set; }
        public string Specialty { get; set; }
        public int ExperienceYears { get; set; }
        public string Department { get; set; }
    }
}